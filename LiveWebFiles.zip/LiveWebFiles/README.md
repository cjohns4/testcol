# tabbed-module-template
**CHANGE LOG**

**4/26/17:**

	*Updated color of <a> tag to meet AA standards in 'colors.css'

**2/14/17: Valentines Day Update**

	*Created publisher_resources folder with Connect and WileyPlus template pages and associated images
	
	*Added animate.css - look it up and play with it, but don't go overboard
	
	*Attempted to fix bug where page doesn't return to top in Firefox on click of Next/Previous button
	
	*Added Proctor reminder alert to tabbed-module-2, simply delete if not needed

**12/19/16:**

	*Updated language in all slickQuiz-config files to be more standardized, easier to edit

**12/7/16:**

	*Updated FontAwesome to v.4.7.0 for increased awesome

	*Updated SlickQuiz feedback language after quiz in config files

	*Added panel for Weekly Objectives on Overview tab

	*Added section for Multimedia on Activities tab


**9/20/16:**

	*Updated colors.css to ensure accessibility of anchor text


**9/2/16**

	*Tabbed module template added to GitHub to manage updates


**9/1/16:**

	*Added css to tabbedmodule.css for tables

	*Changed page titles to "Week x Instructional Materials" to match D2L naming convention

	*Created colors.css which incorporate colors used on the CC website

	*Modified heading structure for accessibility and color scheme

	*Added class "activities" to modify H3 color on Activities tab

	*Added JS code to accomodate up to 15 Lecture tab next/previous buttons

	*Modified semantics of button id that leads to Review tab to #toreview

	*Changed alert at bottom of Activites page to match naming convention in D2L, "Open Forum"
